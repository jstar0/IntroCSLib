#include "JSCalculator.h"

#include <QApplication>

HashMap opMap;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Calculator* w = new Calculator;
    w->setWindowFlags(Qt::FramelessWindowHint);
    w->setAttribute(Qt::WA_TranslucentBackground);
    w->setAttribute(Qt::WA_DeleteOnClose);
    w->show();
    return a.exec();
}

/* 本程序在 Qt6 以下版本可能无法很好地工作。 */

/* 我也原创了一个通过逆波兰表达式（后缀表达式）处理复杂算式 （可以是含括号的表达式）的算法 */
/* 请看根目录 ./CalMethodByJS.cpp */

/* 通过 #ifdef Q_OS_WIN ... #endif 实现平台判断 */
/* 在Windows下调用WinAPI实现模糊效果 */

/* 自定义程序的外观，参考了 Acrylic / Aero 设计风格 */
/* 同时实现了程序宽度增加后，显示右侧菜单的类Windows设计 */
/* 这部分的实现请从 JSCalculator 第一部分开始看 */
/* 引用了部分代码，具体参见： @Linloir (GitHub) 的设计 （Under GPL-2.0 License） */
/* 原作者使用了一些已Deprecated的函数或方法，我进行了修复 */
/* 删除掉很多unused参数，如event, expStr等*/

