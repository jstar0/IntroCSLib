
/* 这是一个通过逆波兰表达式（后缀表达式）处理复杂算式 （可以是含括号的表达式）的算法程序 */
/* 使用C++编写。由于与本项目的实现方法并不甚契合，故仅放置于此，作参考 */

// 引入头文件
#include <iostream>
#include <string>
#include <stack>
#include <cctype>
#include <cmath>
#include <iomanip>
using namespace std;

// 【函数】判断一个字符是否是运算符
bool isOperator(char c) {
    return c == '+' || c == '-' || c == '*' || c == '/' || c == '^';
}

// 【函数】判断一个字符是否是左括号
bool isLeftParenthesis(char c) {
    return c == '(';
}

// 【函数】判断一个字符是否是右括号
bool isRightParenthesis(char c) {
    return c == ')';
}

// 【函数】比较两个运算符的优先级
// 返回值为正数，表示第一个运算符的优先级高于第二个运算符
// 返回值为负数，表示第一个运算符的优先级低于第二个运算符
// 返回值为零，表示两个运算符的优先级相同
int comparePriority(char op1, char op2) {
    if (op1 == '^') {
        return 1; // 幂运算的优先级最高
    }
    if (op2 == '^') {
        return -1; // 幂运算的优先级最高
    }
    if ((op1 == '*' || op1 == '/') && (op2 == '+' || op2 == '-')) {
        return 1; // 乘除运算的优先级高于加减运算
    }
    if ((op1 == '+' || op1 == '-') && (op2 == '*' || op2 == '/')) {
        return -1; // 乘除运算的优先级高于加减运算
    }
    return 0; // 其他情况，优先级相同
}

// 【函数】用于将一个中缀表达式转换为后缀表达式
// 参数为一个字符串，表示中缀表达式
// 返回值为一个字符串，表示后缀表达式
string infixToPostfix(string infix) {
    string postfix = ""; // 初始化后缀表达式为空
    stack<char> opStack; // 初始化运算符栈为空
    for (int i = 0; i < infix.length(); i++) { // 遍历中缀表达式的每个字符
        char c = infix[i];
        if (isdigit(c) || c == '.') { // 如果是数字或小数点，直接输出到后缀表达式
            postfix += c;
        }
        else if (isOperator(c)) { // 如果是运算符
            postfix += ' '; // 在后缀表达式中添加一个空格，用于分隔数字
            while (!opStack.empty() && !isLeftParenthesis(opStack.top()) && comparePriority(opStack.top(), c) >= 0) {
                // 如果运算符栈不为空，且栈顶不是左括号，且栈顶运算符的优先级不低于当前运算符
                postfix += opStack.top(); // 将栈顶运算符弹出并输出到后缀表达式
                opStack.pop();
            }
            opStack.push(c); // 将当前运算符压入运算符栈
        }
        else if (isLeftParenthesis(c)) { // 如果是左括号，直接压入运算符栈
            opStack.push(c);
        }
        else if (isRightParenthesis(c)) { // 如果是右括号
            postfix += ' '; // 在后缀表达式中添加一个空格，用于分隔数字
            while (!opStack.empty() && !isLeftParenthesis(opStack.top())) {
                // 如果运算符栈不为空，且栈顶不是左括号
                postfix += opStack.top(); // 将栈顶运算符弹出并输出到后缀表达式
                opStack.pop();
            }
            if (!opStack.empty() && isLeftParenthesis(opStack.top())) {
                // 如果运算符栈不为空，且栈顶是左括号
                opStack.pop(); // 将栈顶的左括号弹出，但不输出到后缀表达式
            }
        }
    }
    while (!opStack.empty()) { // 如果运算符栈不为空
        postfix += ' '; // 在后缀表达式中添加一个空格，用于分隔数字
        postfix += opStack.top(); // 将栈顶运算符弹出并输出到后缀表达式
        opStack.pop();
    }
    return postfix; // 返回后缀表达式
}

// 【函数】用于计算两个数的某种运算
// 参数为两个浮点数，表示操作数，和一个字符，表示运算符
// 返回值为一个浮点数，表示运算结果
long double calculate(long double a, long double b, char op) {
    switch (op) {
    case '+': return a + b; // 加法
    case '-': return a - b; // 减法
    case '*': return a * b; // 乘法
    case '/': return a / b; // 除法
    case '^': return pow(a, b); // 幂运算
    default: return 0; // 其他情况，返回0
    }
}

// 【函数】用于计算一个后缀表达式的值
// 参数为一个字符串，表示后缀表达式
// 返回值为一个浮点数，表示表达式的值
double evaluatePostfix(string postfix) {
    stack<double> numStack; // 初始化数字栈为空
    for (int i = 0; i < postfix.length(); i++) { // 遍历后缀表达式的每个字符
        char c = postfix[i];
        if (isdigit(c) || c == '.') { // 如果是数字或小数点
            double num = 0; // 初始化一个数字为0
            int dot = -1; // 初始化小数点的位置为-1，表示没有小数点
            while (i < postfix.length() && (isdigit(postfix[i]) || postfix[i] == '.')) {
                // 如果当前字符是数字或小数点，且没有超出后缀表达式的长度
                if (postfix[i] == '.') {
                    dot = 0; // 记录小数点的位置为0，表示有小数点
                }
                else {
                    num = num * 10 + (postfix[i] - '0'); // 将当前字符转换为数字，并累加到num中
                    if (dot >= 0) {
                        dot++; // 如果有小数点，每次小数点的位置加1，表示小数位数
                    }
                }
                i++; // 指针后移一位
            }
            if (dot > 0) {
                num = num / pow(10, dot); // 如果有小数点，将num除以10的小数位数次方，得到真正的小数
            }
            numStack.push(num); // 将num压入数字栈
        }
        else if (isOperator(c)) { // 如果是运算符
            if (numStack.size() < 2) {
                // 如果数字栈的大小小于2，表示后缀表达式不合法，无法进行运算
                return 0; // 返回0
            }
            long double b = numStack.top(); // 弹出数字栈的栈顶元素，作为第二个操作数
            numStack.pop();
            long double a = numStack.top(); // 弹出数字栈的栈顶元素，作为第一个操作数
            numStack.pop();
            long double result = calculate(a, b, c); // 调用calculate函数，计算两个操作数的运算结果
            numStack.push(result); // 将运算结果压入数字栈
        }
    }
    if (numStack.size() == 1) {
        // 如果数字栈的大小为1，表示后缀表达式合法，且栈顶元素为最终结果
        return numStack.top(); // 返回栈顶元素
    }
    return 0; // 其他情况，返回0
}

// 【函数】用于计算一个中缀表达式的值
// 参数为一个字符串，表示中缀表达式
// 返回值为一个浮点数，表示表达式的值
long double evaluateInfix(string infix) {
    string postfix = infixToPostfix(infix); // 将中缀表达式转换为后缀表达式
    return evaluatePostfix(postfix); // 调用evaluatePostfix函数，计算后缀表达式的值
}


int main() {
    string infix; // 定义一个字符串，用于存储中缀表达式
    cout << "请输入中缀表达式：" << endl;
    cin >> infix; // 从标准输入读取中缀表达式
    long double result = evaluateInfix(infix); // 计算中缀表达式的值
    cout << setprecision(15) << result << endl; // 输出计算结果，保留15位小数
    return 0;
}
