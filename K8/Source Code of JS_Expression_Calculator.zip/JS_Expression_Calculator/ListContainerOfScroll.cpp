#include "ListContainerOfScroll.h"

/* 注意：此 ListContainerOfScroll 实现方法摘自 @Linloir (GitHub) 的设计 （Under GPL-2.0 License） */


ListContainerOfScroll::ListContainerOfScroll(QWidget *parent) : QWidget(parent)
{}

void ListContainerOfScroll::paintEvent(QPaintEvent *){
    for(int i = 0; i < widgets.size(); i++){
        widgets[i]->resize(this->width(), widgets[i]->height());
    }
}

void ListContainerOfScroll::AddWidget(QWidget *widget){
    // 加入动画
    this->resize(this->width(), this->height() + widget->height() + spacing);
    widgets.push_back(widget);
    size++;
    ys.push_back(0);
    widget->resize(this->width(), widget->height());
    widget->show();
    QGraphicsOpacityEffect* widgetOpac = new QGraphicsOpacityEffect(widget);
    widgetOpac->setOpacity(0);
    widget->setGraphicsEffect(widgetOpac);
    QParallelAnimationGroup* dpGroup = new QParallelAnimationGroup;
    QSequentialAnimationGroup* newWidgetFadeIn = new QSequentialAnimationGroup;
    for(int i = 0; i < size - 1; i++){
        ys[i] += widget->height() + spacing;
        QPropertyAnimation* move = new QPropertyAnimation(widgets[i], "pos");
        move->setDuration(750);
        move->setStartValue(widgets[i]->pos());
        move->setEndValue(QPoint(widgets[i]->x(), ys[i]));
        move->setEasingCurve(QEasingCurve::InOutQuart);
        dpGroup->addAnimation(move);
    }
    newWidgetFadeIn->addPause(300);
    QPropertyAnimation* fade = new QPropertyAnimation(widgetOpac, "opacity", widget);
    fade->setDuration(300);
    fade->setStartValue(0);
    fade->setEndValue(1);
    newWidgetFadeIn->addAnimation(fade);
    dpGroup->addAnimation(newWidgetFadeIn);
    dpGroup->start();
    connect(dpGroup, &QPropertyAnimation::stateChanged, this, [=]{
        if(dpGroup->state() == QAbstractAnimation::Stopped){
            if(widgetOpac->opacity() != 1){
                fade->start(QAbstractAnimation::DeleteWhenStopped);
                connect(fade,&QPropertyAnimation::finished, this, [=](){widgetOpac->deleteLater();});
            }
            else{
                dpGroup->deleteLater();
                widgetOpac->deleteLater();
            }
        }
    });

}

void ListContainerOfScroll::RemoveWidget(QWidget *widget){
    int index;
    if(widget == nullptr){
        index = size - 1;
        if(index != -1)
            widget = widgets[index];
    }
    else
        index = widgets.indexOf(widget);
    if(index == -1 || widget == nullptr){
        return;
    }
    this->resize(this->width(), this->height() - widget->height() - spacing);
    this->parentWidget()->update();
    widget->hide();
    widget->setParent(nullptr);
    QParallelAnimationGroup* dpGroup = new QParallelAnimationGroup;
    for(int i = index - 1; i >= 0; i--){
        ys[i] -= (widget->height() + spacing);
        QPropertyAnimation* move = new QPropertyAnimation(widgets[i], "pos");
        move->setDuration(750);
        move->setStartValue(widgets[i]->pos());
        move->setEndValue(QPoint(widgets[i]->x(), ys[i]));
        move->setEasingCurve(QEasingCurve::InOutQuart);
        dpGroup->addAnimation(move);
    }
    dpGroup->start(QAbstractAnimation::DeleteWhenStopped);
    widgets.remove(index);
    size--;
    ys.remove(index);
}

void ListContainerOfScroll::clear(){
    int n = size;
    for(int i = 0; i < n; i++){
        RemoveWidget();
    }
}
