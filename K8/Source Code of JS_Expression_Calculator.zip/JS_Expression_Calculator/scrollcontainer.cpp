#include "scrollcontainer.h"

ScrollContainer::ScrollContainer(QWidget *parent) : QWidget(parent)
{

}
