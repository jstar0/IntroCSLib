#include "JSCalculator.h"
#include "ui_JSCalculator.h"
#ifdef Q_OS_WIN
    #include <Windows.h>
#endif

#include <QPainter>
#include <QMouseEvent>
#include <QBitmap>
#include <QColorDialog>
#include <QLabel>

Calculator::Calculator(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Acrylic),
      _width(345),
      _height(500)
{
    ui->setupUi(this);
    ui->verticalLayout->setAlignment(Qt::AlignTop);
    this->resize(_width, _height);
    this->setWindowIcon(QIcon(":/icon/icon"));

    /*********************** 以下是特殊外观实现 ***********************/
    /**** 实现了仿 Acrylic / Aero 风格的程序，是面向Windows10的设计。 ****/
    /****************************************************************/

    // 设定 Acrylic Effect

    // 仅在Windows下设置透明度
    #ifdef Q_OS_WIN
        ColorBkg = QColor(240, 240, 240, 150);
    #endif

    #ifdef Q_OS_LINUX
        ColorBkg = QColor(240, 240, 240, 255);
    #endif

    #ifdef Q_OS_MACOS
        ColorBkg = QColor(240, 240, 240, 255);
    #endif

    // 仅在Windows下使用风格
    #ifdef Q_OS_WIN
    hwnd = HWND(winId());
    huser = GetModuleHandle(L"user32.dll");

        // Aero 风格
        if(huser){
            setWindowCompositionAttribute = (pfnSetWindowCompositionAttribute)GetProcAddress(huser, "SetWindowCompositionAttribute");
            if(setWindowCompositionAttribute){
                ACCENT_POLICY accent = { ACCENT_ENABLE_BLURBEHIND, 0, 0, 0 };
                WINDOWCOMPOSITIONATTRIBDATA data;
                data.Attrib = WCA_ACCENT_POLICY;
                data.pvData = &accent;
                data.cbData = sizeof(accent);
                setWindowCompositionAttribute(hwnd, &data);
            }
        }

        // Acrylic 风格
        // 原作者注： 由于API的问题，在拖拽和移动时可能有卡顿。

        //if(huser){
        //    setWindowCompositionAttribute = (pfnSetWindowCompositionAttribute)GetProcAddress(huser, "SetWindowCompositionAttribute");
        //    if(setWindowCompositionAttribute){
        //        DWORD gradientColor = DWORD(0x50F5F5F5);
        //        ACCENT_POLICY accent = { ACCENT_ENABLE_ACRYLICBLURBEHIND, 0, gradientColor, 0 };
        //        WINDOWCOMPOSITIONATTRIBDATA data;
        //        data.Attrib = WCA_ACCENT_POLICY;
        //        data.pvData = &accent;
        //        data.cbData = sizeof(accent);
        //        setWindowCompositionAttribute(hwnd, &data);
        //    }
        //}
    #endif

    #ifdef Q_OS_LINUX
        qDebug() << "For Linux, UI Effect is defaultly disabled.";
    #endif

    #ifdef Q_OS_MACOS
        qDebug() << "For macOS, UI Effect is defaultly disabled.";
    #endif

    // 拖动大小时的配置
    this->setMouseTracking(true);

    ui->opEqual->setColor(QColor(75, 156, 222, 200));
    ui->opEqual->setHoverColor(QColor(50, 156, 222, 210));
    ui->opEqual->setClickedColor(QColor(0, 120, 215, 200));

    tabPage = new AdditionTabWidget(this);
    tabPage->setMinimumWidth(200);
    tabPage->setMaximumWidth(350);
    ui->mainHLayout->addWidget(tabPage);
    tabPage->hide();

    connect(ui->maximumWindow, SIGNAL(clicked()), this, SLOT(windowMaximum()));


    /*********************** 与计算器相关的代码 ***********************/

    initOpMap();
    ui->displayCur->setTextFormat(Qt::RichText);
    ui->displayCur->setAttribute(Qt::WA_TransparentForMouseEvents);
    ui->displayHis->setTextFormat(Qt::RichText);
    ui->displayHis->setAttribute(Qt::WA_TransparentForMouseEvents);

    // 调整按钮颜色
    ui->opAdd   ->setColor(QColor(249, 249, 249, 191));
    ui->opSub   ->setColor(QColor(249, 249, 249, 191));
    ui->opMulti ->setColor(QColor(249, 249, 249, 191));
    ui->opDiv   ->setColor(QColor(249, 249, 249, 191));
    ui->opSqr   ->setColor(QColor(249, 249, 249, 191));
    ui->opPow   ->setColor(QColor(249, 249, 249, 191));
    ui->opMod   ->setColor(QColor(249, 249, 249, 191));
    ui->opBrckL ->setColor(QColor(249, 249, 249, 191));
    ui->opBrckR ->setColor(QColor(249, 249, 249, 191));
    ui->opClear ->setColor(QColor(249, 249, 249, 191));
    ui->bckSpace->setColor(QColor(249, 249, 249, 191));
    ui->opAdd   ->setHoverColor(QColor(71, 71, 71, 71));
    ui->opSub   ->setHoverColor(QColor(71, 71, 71, 71));
    ui->opMulti ->setHoverColor(QColor(71, 71, 71, 71));
    ui->opDiv   ->setHoverColor(QColor(71, 71, 71, 71));
    ui->opSqr   ->setHoverColor(QColor(71, 71, 71, 71));
    ui->opPow   ->setHoverColor(QColor(71, 71, 71, 71));
    ui->opMod   ->setHoverColor(QColor(71, 71, 71, 71));
    ui->opBrckL ->setHoverColor(QColor(71, 71, 71, 71));
    ui->opBrckR ->setHoverColor(QColor(71, 71, 71, 71));
    ui->opClear ->setHoverColor(QColor(71, 71, 71, 71));
    ui->bckSpace->setHoverColor(QColor(71, 71, 71, 71));
    ui->opAdd   ->setClickedColor(QColor(29, 29, 29, 71));
    ui->opSub   ->setClickedColor(QColor(29, 29, 29, 71));
    ui->opMulti ->setClickedColor(QColor(29, 29, 29, 71));
    ui->opDiv   ->setClickedColor(QColor(29, 29, 29, 71));
    ui->opSqr   ->setClickedColor(QColor(29, 29, 29, 71));
    ui->opPow   ->setClickedColor(QColor(29, 29, 29, 71));
    ui->opMod   ->setClickedColor(QColor(29, 29, 29, 71));
    ui->opBrckL ->setClickedColor(QColor(29, 29, 29, 71));
    ui->opBrckR ->setClickedColor(QColor(29, 29, 29, 71));
    ui->opClear ->setClickedColor(QColor(29, 29, 29, 71));
    ui->bckSpace->setClickedColor(QColor(29, 29, 29, 71));

    // 调整按钮字体
    ui->opAdd   ->_setFont(QFont("Arita Sans Thin", 22));
    ui->opSub   ->_setFont(QFont("Arita Sans Thin", 22));
    ui->opMulti ->_setFont(QFont("Arita Sans Thin", 19));
    ui->opDiv   ->_setFont(QFont("Arita Sans Thin", 12));
    ui->opSqr   ->_setFont(QFont("Microsoft YaHei Light", 12));
    ui->opPow   ->_setFont(QFont("Microsoft YaHei Light", 12));
    ui->opMod   ->_setFont(QFont("Microsoft YaHei Light", 12));
    ui->opBrckL ->_setFont(QFont("Arita Sans Thin", 12));
    ui->opBrckR ->_setFont(QFont("Arita Sans Thin", 12));
    ui->opClear ->_setFont(QFont("Microsoft YaHei Light", 12));
    ui->bckSpace->_setFont(QFont("Arita Sans Thin", 11));

    ui->num0->_setFont(QFont("Microsoft YaHei", 13));
    ui->num1->_setFont(QFont("Microsoft YaHei", 13));
    ui->num2->_setFont(QFont("Microsoft YaHei", 13));
    ui->num3->_setFont(QFont("Microsoft YaHei", 13));
    ui->num4->_setFont(QFont("Microsoft YaHei", 13));
    ui->num5->_setFont(QFont("Microsoft YaHei", 13));
    ui->num6->_setFont(QFont("Microsoft YaHei", 13));
    ui->num7->_setFont(QFont("Microsoft YaHei", 13));
    ui->num8->_setFont(QFont("Microsoft YaHei", 13));
    ui->num9->_setFont(QFont("Microsoft YaHei", 13));

    // 连接被点击的按钮
    // 注意： QObject::connect 应该被传递三个参数，当context被删除时，表达式不必被执行，防止内存泄露。
    connect(ui->num0, &QPushButton::clicked, this, [=]{expr.insert('0'); RfrInput(); UpdStack();});
    connect(ui->num1, &QPushButton::clicked, this, [=](){expr.insert('1'); RfrInput(); UpdStack();});
    connect(ui->num2, &QPushButton::clicked, this, [=](){expr.insert('2'); RfrInput(); UpdStack();});
    connect(ui->num3, &QPushButton::clicked, this, [=](){expr.insert('3'); RfrInput(); UpdStack();});
    connect(ui->num4, &QPushButton::clicked, this, [=](){expr.insert('4'); RfrInput(); UpdStack();});
    connect(ui->num5, &QPushButton::clicked, this, [=](){expr.insert('5'); RfrInput(); UpdStack();});
    connect(ui->num6, &QPushButton::clicked, this, [=](){expr.insert('6'); RfrInput(); UpdStack();});
    connect(ui->num7, &QPushButton::clicked, this, [=](){expr.insert('7'); RfrInput(); UpdStack();});
    connect(ui->num8, &QPushButton::clicked, this, [=](){expr.insert('8'); RfrInput(); UpdStack();});
    connect(ui->num9, &QPushButton::clicked, this, [=](){expr.insert('9'); RfrInput(); UpdStack();});
    connect(ui->opDot, &QPushButton::clicked, this, [=](){expr.insert('.'); RfrInput(); UpdStack();});
    connect(ui->opAdd, &QPushButton::clicked, this, [=](){expr.insert('+'); RfrInput(); UpdStack();});
    connect(ui->opSub, &QPushButton::clicked, this, [=](){expr.insert('-'); RfrInput(); UpdStack();});
    connect(ui->opMulti, &QPushButton::clicked, this, [=](){expr.insert('*'); RfrInput(); UpdStack();});
    connect(ui->opDiv, &QPushButton::clicked, this, [=](){expr.insert('/'); RfrInput(); UpdStack();});
    connect(ui->opSqr, &QPushButton::clicked, this, [=](){expr.insert('^'); RfrInput(); UpdStack(); expr.insert('2'); RfrInput(); UpdStack(); });
    connect(ui->opPow, &QPushButton::clicked, this, [=](){expr.insert('^'); RfrInput(); UpdStack();});
    connect(ui->opMod, &QPushButton::clicked, this, [=](){expr.insert('%'); RfrInput(); UpdStack();});
    connect(ui->opBrckL, &QPushButton::clicked, this, [=](){expr.insert('('); RfrInput(); UpdStack();});
    connect(ui->opBrckR, &QPushButton::clicked, this, [=](){expr.insert(')'); RfrInput(); UpdStack();});
    connect(ui->opEqual, &QPushButton::clicked, this, [=](){expr.insert('#');  UpdStack(); RfrInput(); RfrResult(); UpdHistory();});
    connect(ui->opClear, &QPushButton::clicked, this, [=](){expr.clr(); RfrInput(); UpdStack(true);});
    connect(ui->bckSpace, &QPushButton::clicked, this, [=](){expr.backSpace(); RfrInput(); UpdStack(true);});

    // 注：非标准化的签名会导致不必要的内存分配，影响性能.在这里进行修改。
    connect(this, SIGNAL(addHistoryTerm(QString,QString,QString)), tabPage, SLOT(Controller_AddHistoryTerm(QString,QString,QString)));
    //connect(this, SIGNAL(addHistoryTerm(const QString &, const QString &, const QString &)), tabPage, SLOT(Controller_AddHistoryTerm(const QString &, const QString &, const QString &)));
    connect(this, SIGNAL(updateStackPage(QString,QString)), tabPage, SLOT(Controller_UpdateStackPage(QString,QString)));
    //connect(this, SIGNAL(updateStackPage(const QString &, const QString &)), tabPage, SLOT(Controller_UpdateStackPage(const QString &, const QString &)));

}

Calculator::~Calculator()
{
    delete ui;
}

void Calculator::paintEvent(QPaintEvent *){ //！
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing);
    QPen pen;
    pen.setColor(QColor(0,0,0,255));
    pen.setStyle(Qt::SolidLine);
    pen.setWidth(1);
    painter.setPen(pen);
    painter.setBrush(ColorBkg);
    painter.drawRect(this->rect());
    ui->TitleBar->resize(this->rect().width() - 10, ui->TitleBar->height());
}

void Calculator::mouseMoveEvent(QMouseEvent *event){
    if(pressed){
        if(mouseState == 0){
            // QMouseEvent::globalPos()函数在Qt6中已经被弃用
            // 使用QMouseEvent::globalPosition().toPoint()函数代替。
            QPoint displacement = event->globalPosition().toPoint() - mousePos_strt;
            // QPoint displacement = event->globalPos() - mousePos_strt;
            this->move(displacement);
        }
        else if(mouseState == 1){
            // 重设宽度
            int displacementX = event->pos().x() - this->rect().width();
            if(this->rect().width() + displacementX >= _width){
                this->resize(this->rect().width() + displacementX, this->rect().height());
            }
        }
        else if(mouseState == 2){
            // 重设高度
            int displacementY = event->pos().y() - this->rect().height();
            if(this->rect().height() + displacementY >= _height)
                this->resize(this->rect().width(), this->rect().height() + displacementY);
        }
        else{
            int displacementX = event->pos().x() - this->rect().width();
            if(this->rect().width() + displacementX >= _width)
                this->resize(this->rect().width() + displacementX, this->rect().height());
            int displacementY = event->pos().y() - this->rect().height();
            if(this->rect().height() + displacementY >= _height)
                this->resize(this->rect().width(), this->rect().height() + displacementY);
        }
        if(!tabShown && this->rect().width() >= 595){
            tabPage->show();
            tabShown = true;
        }
        if(tabShown && this->rect().width() < 595){
            tabPage->hide();
            tabShown = false;
        }
    }
    else{
        int _x = abs(event->pos().x()- this->rect().width());
        int _y = abs(event->pos().y() - this->rect().height());
        if(_x < 10 && _y < 10){
            this->setCursor(Qt::SizeFDiagCursor);
            mouseState = 3;
        }
        else if(_x < 5 && _y > 5 && event->pos().y() > ui->TitleBar->height()){
            this->setCursor(Qt::SizeHorCursor);
            mouseState = 1;
        }
        else if(_x > 5 && _y < 5){
            this->setCursor(Qt::SizeVerCursor);
            mouseState = 2;
        }
        else{
            this->setCursor(Qt::ArrowCursor);
            mouseState = 0;
        }
    }
}

void Calculator::mousePressEvent(QMouseEvent *event){
    mousePos_strt = event->pos();
    pressed = true;
}

void Calculator::mouseReleaseEvent(QMouseEvent *){ //！！
    pressed = false;
    this->setCursor(Qt::ArrowCursor);
    mouseState = 0;
}

void Calculator::RfrInput(){
    ui->displayHis->setText("");
    if(expr.expToHtml().isEmpty()){
        ui->displayCur->setText("0");
        ui->displayHis->clear();
    }
    else
        ui->displayCur->setText(expr.expToHtml().replace('/', "÷").replace('*', "×"));
}

void Calculator::RfrResult(){
    ui->displayHis->setText(expr.expToHtml().replace('/', "÷").replace('*', "×"));
    ui->displayCur->setText(expr.resToHtml());
}

void Calculator::UpdStack(bool r){
    QString numDif;
    if(r){
        numDif.append('r');
        numDif.append(expr.numStackToStr());
    }
    else{
        numDif = expr.numDifStr();
    }
    QString opDif;
    if(r){
        opDif.append('r');
        opDif.append(expr.opStackToStr());
    }
    else{
        opDif = expr.opDifStr();
    }
    emit updateStackPage(numDif, opDif);
    update();
}

void Calculator::UpdHistory(){
    emit addHistoryTerm(expr.expStr(), expr.expToHtml(), expr.resToHtml());
    if(expr.prepare())
        UpdStack(true);
    update();
}


void Calculator::windowMaximum(){
    if(!isMaximum){
        lastWidth = this->width();
        lastHeight = this->height();
        this->showFullScreen();
        ui->maximumWindow->setText("▽");
        isMaximum = true;
    }
    else{
        this->showNormal();
        this->resize(lastWidth, lastHeight);
        ui->maximumWindow->setText("□");
        isMaximum = false;
    }
}

void Calculator::keyPressEvent(QKeyEvent *event){
    switch(event->key()){
    case Qt::Key_0:
        expr.insert('0');
        RfrInput();
        UpdStack();
        break;
    case Qt::Key_1:
        expr.insert('1');
        RfrInput();
        UpdStack();
        break;
    case Qt::Key_2:
        expr.insert('2');
        RfrInput();
        UpdStack();
        break;
    case Qt::Key_3:
        expr.insert('3');
        RfrInput();
        UpdStack();
        break;
    case Qt::Key_4:
        expr.insert('4');
        RfrInput();
        UpdStack();
        break;
    case Qt::Key_5:
        expr.insert('5');
        RfrInput();
        UpdStack();
        break;
    case Qt::Key_6:
        expr.insert('6');
        RfrInput();
        UpdStack();
        break;
    case Qt::Key_7:
        expr.insert('7');
        RfrInput();
        UpdStack();
        break;
    case Qt::Key_8:
        expr.insert('8');
        RfrInput();
        UpdStack();
        break;
    case Qt::Key_9:
        expr.insert('9');
        RfrInput();
        UpdStack();
        break;
    case Qt::Key_ParenLeft:
        expr.insert('(');
        RfrInput();
        UpdStack();
        break;
    case Qt::Key_ParenRight:
        expr.insert(')');
        RfrInput();
        UpdStack();
        break;
    case Qt::Key_Backspace:
        expr.backSpace();
        RfrInput();
        UpdStack(true);
        break;
    case Qt::Key_Plus:
        expr.insert('+');
        RfrInput();
        UpdStack();
        break;
    case Qt::Key_Minus:
        expr.insert('-');
        RfrInput();
        UpdStack();
        break;
    case Qt::Key_Asterisk:
        expr.insert('*');
        RfrInput();
        UpdStack();
        break;
    case Qt::Key_Slash:
        expr.insert('/');
        RfrInput();
        UpdStack();
        break;
    case Qt::Key_Percent:
        expr.insert('%');
        RfrInput();
        UpdStack();
        break;
    case Qt::Key_AsciiCircum:
        expr.insert('^');
        RfrInput();
        UpdStack();
        break;
    case Qt::Key_C:
        expr.clr();
        RfrInput();
        UpdStack(true);
        break;
    case Qt::Key_Period:
        expr.insert('.');
        RfrInput();
        UpdStack();
        break;
    case Qt::Key_Equal:
    case Qt::Key_Enter:
    case Qt::Key_Return:
        expr.insert('#');
        UpdStack();
        RfrInput();
        RfrResult();
        UpdHistory();
    default:
        break;
    }
}
