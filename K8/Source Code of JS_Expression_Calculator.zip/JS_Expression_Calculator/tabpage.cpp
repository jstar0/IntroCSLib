#include "tabpage.h"

/* 注意：此 TabPage 的实现方法摘自 @Linloir (GitHub) 的设计 （Under GPL-2.0 License） */

TabPage::TabPage(QWidget *parent) : QWidget(parent)
{
    this->setMouseTracking(true);
}
