#include "IndicatorOfScroll.h"

/* 注意：此 IndicatorOfScroll 实现方法摘自 @Linloir (GitHub) 的设计 （Under GPL-2.0 License） */

IndicatorOfScroll::IndicatorOfScroll(QWidget *parent) : QWidget(parent)
{
    this->resize(defaultWidth, 0);
    hovTimer = new QTimer(this);
    hovTimer->setSingleShot(true);
    aniPause = new QTimer(this);
    aniPause->setSingleShot(true);
    QObject::connect(hovTimer, SIGNAL(timeout()), this, SLOT(setHoverActive()));
    this->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
    this->curColor = defaultColor;

    this->setMouseTracking(true);
}

void IndicatorOfScroll::paintEvent(QPaintEvent *){
    QPainter painter(this);
    painter.setPen(Qt::NoPen);
    painter.setBrush(curColor);
    painter.drawRect(this->rect());
}

void IndicatorOfScroll::enterEvent(QEnterEvent *){
    if(!pressed){
        hovTimer->start(100);
        curColor = hoverColor;
        update();
    }
}

void IndicatorOfScroll::leaveEvent(QEvent *){
    hovTimer->stop();
    curColor = defaultColor;
    QPropertyAnimation* narrow = new QPropertyAnimation(this, "geometry");
    narrow->setDuration(300);
    narrow->setStartValue(QRect(this->x(), this->y(), this->width(), this->height()));
    narrow->setEndValue(QRect(this->parentWidget()->width() - margin - defaultWidth, this->y(), defaultWidth, this->height()));
    narrow->setEasingCurve(QEasingCurve::InOutQuad);
    narrow->start(QAbstractAnimation::DeleteWhenStopped);
    aniPause->start(300);
    update();
}

void IndicatorOfScroll::mousePressEvent(QMouseEvent *event){
    curColor = pressColor;
    pressed = true;
    lastY = event->globalPosition().y();
    //lastY = event->globalPos().y();
    update();
}

void IndicatorOfScroll::mouseMoveEvent(QMouseEvent *event){
    if(pressed && !aniPause->isActive()){
        int dp = event->globalPosition().y() - lastY;
        //int dp = event->globalPos().y() - lastY;
        emit scrollPage(dp);
        lastY = event->globalPosition().y();
        //lastY = event->globalPos().y();
    }
}

void IndicatorOfScroll::mouseReleaseEvent(QMouseEvent *){
    pressed = false;
    curColor = hoverColor;
    update();
}

void IndicatorOfScroll::setHoverActive(){
    QPropertyAnimation* widen = new QPropertyAnimation(this, "geometry");
    widen->setDuration(300);
    widen->setStartValue(QRect(this->x(), this->y(), this->width(), this->height()));
    widen->setEndValue(QRect(this->parentWidget()->width() - margin - defaultWidthAtFocus, this->y(), defaultWidthAtFocus, this->height()));
    widen->setEasingCurve(QEasingCurve::InOutQuad);
    widen->start(QAbstractAnimation::DeleteWhenStopped);
    aniPause->start(300);
}
