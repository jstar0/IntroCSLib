#include "tabicons.h"

/* 注意：此 TabIcons 的实现方法摘自 @Linloir (GitHub) 的设计 （Under GPL-2.0 License） */

TabIcons::TabIcons(QWidget* parent): QPushButton(parent)
{
    this->setMouseTracking(true);
    QFont textFont;
    textFont.setFamily("DengXian");
    textFont.setPointSize(15);
    QFontMetrics fm(textFont);
    this->setMinimumSize(fm.boundingRect(this->text()).width() + 30, fm.ascent() - fm.descent() + fm.leading() + 20);
    this->resize(fm.boundingRect(this->text()).width() + 30, fm.ascent() - fm.descent() + fm.leading());

    this->setStyleSheet("background-color = background-color: rgba(255, 255, 255, 0);");
    this->setFlat(true);

    currentColor = defaultColorNotAtFocus;
}

TabIcons::TabIcons(const QString & name, QWidget* parent) : QPushButton(parent){
    this->setMouseTracking(true);
    this->setText(name);
    QFont textFont;
    textFont.setFamily("DengXian");
    textFont.setPointSize(15);
    QFontMetrics fm(textFont);
    this->setMinimumSize(fm.boundingRect(this->text()).width() + 30, fm.ascent() - fm.descent() + fm.leading() + 20);
    this->resize(fm.boundingRect(this->text()).width() + 30, fm.ascent() - fm.descent() + fm.leading() + 20);

    this->setStyleSheet("background-color = background-color: rgba(255, 255, 255, 0);");
    this->setFlat(true);

    currentColor = defaultColorNotAtFocus;
}

void TabIcons::paintEvent(QPaintEvent *){
    QPainter textPainter(this);
    textPainter.setPen(currentColor);
    QFont textFont("DengXian", 15);
    textPainter.setFont(textFont);
    int widthOfText = textPainter.fontMetrics().size(Qt::TextSingleLine, this->text()).width();
    textPainter.drawText(this->width() / 2 - widthOfText / 2, this->height() - 5, this->text());
}

void TabIcons::enterEvent(QEnterEvent *){
    currentColor = hoverColor;
    update();
}

void TabIcons::leaveEvent(QEvent *){
    currentColor = atFocus ? defaultColorAtFocus : defaultColorNotAtFocus;
    update();
}

void TabIcons::mousePressEvent(QMouseEvent *){
    currentColor = pressColor;
    update();
    emit SelectPage(this);
}

void TabIcons::mouseReleaseEvent(QMouseEvent *){
    currentColor = atFocus ? defaultColorAtFocus : hoverColor;
    update();
}

void TabIcons::SetFocus(bool status){
    atFocus = status;
    currentColor = atFocus ? defaultColorAtFocus : defaultColorNotAtFocus;
    update();
}
