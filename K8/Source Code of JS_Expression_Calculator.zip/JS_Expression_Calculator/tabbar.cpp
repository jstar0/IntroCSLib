#include "tabbar.h"

TabBar::TabBar(QWidget *parent) : QWidget(parent)
{

}
