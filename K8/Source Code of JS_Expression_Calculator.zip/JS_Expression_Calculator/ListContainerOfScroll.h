#ifndef LISTCONTAINEROFSCROLL_H
#define LISTCONTAINEROFSCROLL_H

#include <QWidget>
#include <QVBoxLayout>
#include <QPushButton>
#include <QPropertyAnimation>
#include <QParallelAnimationGroup>
#include <QSequentialAnimationGroup>
#include <QGraphicsOpacityEffect>
#include <QVector>
#include <QTimer>

class ListContainerOfScroll : public QWidget
{
    Q_OBJECT
public:
    explicit ListContainerOfScroll(QWidget *parent = nullptr);
    void AddWidget(QWidget* widget);
    void RemoveWidget(QWidget* widget = nullptr);
    void clear();
    //void RemoveWidget(QWidget* widget);

private:
    //QTimer* newWidgetFade;
    int spacing = 3;
    QVector<QWidget*> widgets;
    int size = 0;
    QVector<int> ys;

    void paintEvent(QPaintEvent* event);

signals:

private slots:

};

#endif // LISTCONTAINEROFSCROLL_H
