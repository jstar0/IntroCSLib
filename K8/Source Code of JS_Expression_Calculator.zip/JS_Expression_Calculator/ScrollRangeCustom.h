#ifndef SCROLLRANGECUSTOM_H
#define SCROLLRANGECUSTOM_H

#include <QWidget>
#include <QTimer>
#include <QVector>
#include <QPainter>
#include <QMouseEvent>
#include <QWheelEvent>
#include <QGraphicsOpacityEffect>
#include <QPropertyAnimation>
#include "ListContainerOfScroll.h"
#include "IndicatorOfScroll.h"
#include <QDebug>
#include <QQueue>

#define MAXSPEED 50

class ScrollRangeCustom : public QWidget
{
    Q_OBJECT

private:
    QTimer* getCord;
    QTimer* rfrshView;
    
    ListContainerOfScroll* container;
    IndicatorOfScroll* indicator;

    QPropertyAnimation* bounce;

    bool pressed = false;
    bool scrollDown = true;
    bool outOfEdge = false;

    int strtY;
    int lastY;
    int bfEdgeY;    //last y value before out of edge

    int curSpd = 0;
    int damp = 1;
    int moveStored = 0;
    int nextMove = 1;

    void paintEvent(QPaintEvent* event);
    void mousePressEvent(QMouseEvent* event);
    void mouseMoveEvent(QMouseEvent* event);
    void mouseReleaseEvent(QMouseEvent* event);
    void wheelEvent(QWheelEvent* event);
    void bounceBack();


public:
    explicit ScrollRangeCustom(QWidget *parent = nullptr);
    void addWidget(QWidget* newWidget);
    void removeWidget(QWidget* w  = nullptr);
    void clear();

signals:

private slots:
    void scrollContainer();
    void updateSpd();
    void scrollIndicator(int dp);

};

#endif // SCROLLRANGECUSTOM_H
