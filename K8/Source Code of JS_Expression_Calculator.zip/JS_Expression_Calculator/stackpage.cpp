#include "stackpage.h"

/* 注意：此 StackPage 的实现方法摘自 @Linloir (GitHub) 的设计 （Under GPL-2.0 License） */

StackPage::StackPage(QWidget* parent) : TabPage(parent)
{
    this->setMouseTracking(true);
    QHBoxLayout* mainLayout = new QHBoxLayout;
    mainLayout->setContentsMargins(0, 0, 0, 0);
    this->setLayout(mainLayout);

    QVBoxLayout* numLayout = new QVBoxLayout;
    numLayout->setContentsMargins(0, 0, 0, 0);
    QLabel* labNum = new QLabel;
    QFont labFont("DengXian", 13);
    labFont.setBold(true);
    labNum->setText("数栈");
    labNum->setFont(labFont);
    labNum->setAlignment(Qt::AlignRight | Qt::AlignTop);
    labNum->setStyleSheet("color:#E75E5E5E;");
    labNum->setMaximumHeight(20);
    numLayout->addWidget(labNum);
    
    numStackScrollArea = new ScrollRangeCustom(this);
    numLayout->addWidget(numStackScrollArea);

    QVBoxLayout* opLayout = new QVBoxLayout;
    opLayout->setContentsMargins(0, 0, 0, 0);
    QLabel* labOp = new QLabel;
    labFont.setBold(true);
    labOp->setText("运算符栈");
    labOp->setFont(labFont);
    labOp->setAlignment(Qt::AlignRight | Qt::AlignTop);
    labOp->setStyleSheet("color:#E75E5E5E;");
    labOp->setMaximumHeight(20);
    opLayout->addWidget(labOp);
    
    opStackScrollArea = new ScrollRangeCustom(this);
    opLayout->addWidget(opStackScrollArea);

    mainLayout->addLayout(opLayout);
    mainLayout->addLayout(numLayout);
}

void StackPage::RfrStack(const QString & numDif, const QString & opDif){
    QString numDifCpy = numDif;
    if(!numDif.isEmpty()){
        QTextStream numStream(&numDifCpy);
        if(numDif[0] == 'r'){
            numStackScrollArea->clear();
            numDifCpy.remove(0, 1);
        }
        while(!numStream.atEnd()){
            char op;
            numStream >> op;
            if(op == 'o'){
                numStackScrollArea->removeWidget();
            }
            else if(op == 'i'){
                double num;
                numStream >> num;
                QLabel* newNum = new QLabel;
                QFont font("DengXian", 20);
                font.setBold(true);
                newNum->setFont(font);
                newNum->setAlignment(Qt::AlignRight);
                newNum->resize(newNum->width(), 30);
                newNum->setText(QString::asprintf("%g", num));
                numStackScrollArea->addWidget(newNum);
            }
        }
    }
    QString opDifCpy = opDif;
    opDifCpy.replace('*', "×").replace('/', "÷");
    if(!opDif.isEmpty()){
        QTextStream opStream(&opDifCpy);
        if(opDif[0] == 'r'){
            opStackScrollArea->clear();
            opDifCpy.remove(0, 1);
        }
        while(!opStream.atEnd()){
            char op;
            opStream >> op;
            if(op == 'o'){
                opStackScrollArea->removeWidget();
            }
            else if(op == 'i'){
                char c;
                opStream >> c;
                QLabel* newChar = new QLabel;
                QFont font("DengXian", 20);
                font.setBold(false);
                newChar->setFont(font);
                newChar->setAlignment(Qt::AlignRight);
                newChar->resize(newChar->width(), 30);
                newChar->setText(QString::asprintf("%c%s", c, c == '(' ? " " : ""));
                opStackScrollArea->addWidget(newChar);
            }
        }
    }
}

void StackPage::paintEvent(QPaintEvent *){
}
