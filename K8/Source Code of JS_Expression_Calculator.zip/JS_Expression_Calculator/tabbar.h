#ifndef TABBAR_H
#define TABBAR_H

#include <QWidget>

class TabBar : public QWidget
{
    Q_OBJECT
public:
    explicit TabBar(QWidget *parent = nullptr);

signals:

};

#endif // TABBAR_H
