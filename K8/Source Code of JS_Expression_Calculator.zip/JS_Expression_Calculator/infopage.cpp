#include "infopage.h"

/* 注意：此InfoPage的实现方法摘自 @Linloir (GitHub) 的设计 （Under GPL-2.0 License） */

InfoPage::InfoPage(QWidget* parent) : TabPage(parent)
{
    QVBoxLayout* mainLayout = new QVBoxLayout;
    mainLayout->setContentsMargins(0, 0, 0, 0);
    this->setLayout(mainLayout);

    QFile htmlPage(":/html/info.html");
    QString html;
    if (htmlPage.open(QIODevice::ReadOnly | QIODevice::Text)){
        while (!htmlPage.atEnd()){
            QByteArray line = htmlPage.readLine();
            QString str(line);
            html.append(str);
        }
        htmlPage.close();
    }
    else{
        html.append("<h2>\
    <span style=\"font-size:14px;\"><strong><span style=\"font-size:16px;\">无法找到文件</span></strong></span>\
</h2>\
<p>\
    <span style=\"font-size:14px;\"><strong>请检查应用完整性：</strong> <span style=\"color:#337FE5;\">./info.html</span></span> \
</p>\
<p>\
    <span style=\"font-size:14px;color:#000000;\"><span style=\"color:#000000;\"><strong>作者： </strong><span style=\"color:#337FE5;\">于景一 计算机类1班 23090032047</span></span></span>\
</p>\
<p>\
    <span><span style=\"font-size:14px;color:#000000;\"><strong>风格参考: </strong><span style=\"color:#337FE5;\">@Linloir (GitHub) （Under GPL-2.0 License）</span></span></span>\
</p>\
<p>\
    <br />\
</p>");
    }

    QTextBrowser* InfoBrowser = new QTextBrowser;
    InfoBrowser->setHtml(html);
    InfoBrowser->setStyleSheet("background:transparent;border-width:0;border-style:outset");
    InfoBrowser->setOpenExternalLinks(true);
    InfoBrowser->resize(InfoBrowser->width(), 550);

    ScrollRangeCustom* scrollarea = new ScrollRangeCustom(this);
    mainLayout->addWidget(scrollarea);
    scrollarea->addWidget(InfoBrowser);
}
