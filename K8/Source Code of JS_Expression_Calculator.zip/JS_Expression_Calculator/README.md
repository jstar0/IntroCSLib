# Acrylic_Expression_Calculator_in_Qt
An Acrylic Expression Calculator

Readme will upload later~

------------------
# Some screen shots
![Main screen](https://user-images.githubusercontent.com/30849181/136970890-b4506f2b-02bb-4c31-9e5c-3422b350fac6.jpg)
![Expression validity check](https://user-images.githubusercontent.com/30849181/136970948-ca1b628f-6b06-445a-916a-fa01420e0989.jpg)
