#include "tabindicator.h"

/* 注意：此 TabIndicator 的实现方法摘自 @Linloir (GitHub) 的设计 （Under GPL-2.0 License） */

TabIndicator::TabIndicator(QWidget *parent) : QWidget(parent)
{
    this->setSizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
    this->setMouseTracking(true);
}

void TabIndicator::paintEvent(QPaintEvent *){
    QPainter painter(this);
    painter.setPen(QColor(0, 119, 216, 199));
    painter.setBrush(QColor(0, 119, 216, 199));
    painter.drawRect(this->rect());
}
