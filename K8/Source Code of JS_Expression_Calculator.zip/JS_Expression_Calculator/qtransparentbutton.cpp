#include "qtransparentbutton.h"

/* 注意：此 TransparentButton 实现方法摘自 @Linloir (GitHub) 的设计 （Under GPL-2.0 License） */
/* 旨在使按钮透明 */

QTransparentButton::QTransparentButton(QWidget* parent) : QPushButton(parent)
{
    bgColor = bgColor_default;
    buttonText = this->text();
}

void QTransparentButton::paintEvent(QPaintEvent *){
    QPainter bgPainter(this);
    bgPainter.setPen(Qt::NoPen);
    bgPainter.setBrush(bgColor);
    bgPainter.drawRect(this->rect());
    buttonText = this->text();

    QPainter textPainter(this);
    textPainter.setRenderHint(QPainter::TextAntialiasing);
    textPainter.setPen(textColor);
    textFont.setBold(bold);
    textPainter.setFont(textFont);
    int widthOfText = textPainter.fontMetrics().size(Qt::TextSingleLine, buttonText).width();
    int heightOfText = textPainter.fontMetrics().ascent() - textPainter.fontMetrics().descent() + textPainter.fontMetrics().leading();
    textPainter.drawText(this->width() / 2 - widthOfText / 2, this->height() / 2 + heightOfText / 2, buttonText);
}

void QTransparentButton::enterEvent(QEnterEvent *){
    bgColor = bgColor_Hover;
    update();
}

void QTransparentButton::leaveEvent(QEvent *){
    bgColor = bgColor_default;
    update();
}

void QTransparentButton::mousePressEvent(QMouseEvent *){
    emit clicked();
    bgColor = bgColor_Clicked;
    update();
}

void QTransparentButton::mouseReleaseEvent(QMouseEvent *){
    bgColor = bgColor_Hover;
    update();
}

void QTransparentButton::setColor(QColor c){
    bgColor_default = c;
    bgColor = bgColor_default;
}

void QTransparentButton::setHoverColor(QColor c){
    bgColor_Hover = c;
}

void QTransparentButton::setClickedColor(QColor c){
    bgColor_Clicked = c;
}
