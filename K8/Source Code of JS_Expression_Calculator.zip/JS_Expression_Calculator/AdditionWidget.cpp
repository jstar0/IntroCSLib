#include "AdditionWidget.h"

/* 注意：此 AdditionWidget 实现方法摘自 @Linloir (GitHub) 的设计 （Under GPL-2.0 License） */

AdditionTabWidget::AdditionTabWidget(QWidget *parent) : QWidget(parent)
{
    this->setMouseTracking(true);

    // 设置主页面布局
    QVBoxLayout* mainLayout = new QVBoxLayout;
    mainLayout->setContentsMargins(0, 0, 0, 0);
    mainLayout->setSpacing(15);
    this->setLayout(mainLayout);

    // 设置 TabBar
    iconContents = new QWidget(this);
    QHBoxLayout* iconHLayout = new QHBoxLayout;
    iconHLayout->setContentsMargins(0, 0, 0, 0);
    iconHLayout->setSpacing(0);
    iconHLayout->setAlignment(Qt::AlignLeft);
    iconContents->setLayout(iconHLayout);
    iconContents->setMouseTracking(true);

    // 设置 Indicator
    indicator = new TabIndicator(this);
    indicator->resize(0, 3);

    // 设置 页面容器
    pageContainer = new QWidget(this);
    pageContainer->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    pageContainer->setMouseTracking(true);

    mainLayout->addWidget(iconContents);
    mainLayout->addWidget(pageContainer);

    HistoryPage* historyPg = new HistoryPage(pageContainer);
    TabIcons* hisIcon = new TabIcons("历史记录", iconContents);
    pages.push_back(historyPg);
    tabButtons.push_back(hisIcon);
    // 修改规范化的签名，更符合Qt6规范
    QObject::connect(this, SIGNAL(sig_AddHistory(QString,QString,QString)), historyPg, SLOT(AddHistory(QString,QString,QString)));

    StackPage* stackPg = new StackPage(pageContainer);
    TabIcons* stckIcon = new TabIcons("存储栈", iconContents);
    pages.push_back(stackPg);
    tabButtons.push_back(stckIcon);
    QObject::connect(this, SIGNAL(sig_UpdateStackPage(QString,QString)), stackPg, SLOT(RfrStack(QString,QString)));

    InfoPage* infoPg = new InfoPage(pageContainer);
    TabIcons* infoIcon = new TabIcons("关于应用", iconContents);
    pages.push_back(infoPg);
    tabButtons.push_back(infoIcon);

    /*********************************************************/

    // 设置全部页面
    for(int i = 0; i < pages.size(); i++){
        pages[i]->move(0, 0);
        pages[i]->resize(pageContainer->size());
        pages[i]->hide();
    }

    for(int i = 0; i < tabButtons.size(); i++){
        iconHLayout->addWidget(tabButtons[i]);
        QObject::connect(tabButtons[i], SIGNAL(SelectPage(TabIcons*)), this, SLOT(ShiftPage(TabIcons*)));
    }

    // 设置默认显示页面 和 Indicator
    pages[0]->show();
    tabButtons[0]->SetFocus(true);
    indicator->resize(tabButtons[0]->size().width() - 30, 3);
    indicator->move(15, iconContents->height() + 10);
    indicator->raise();
    currentPageIndex = 0;

}

void AdditionTabWidget::paintEvent(QPaintEvent *){
    if(currentPageIndex != -1){
        pages[currentPageIndex]->resize(pageContainer->size());
    }

}

void AdditionTabWidget::ShiftPage(TabIcons* sel){
    // 设置 Index
    int index = tabButtons.indexOf(sel);
    if(index == currentPageIndex)
        return;

    // 选择新页面，加入容器
    TabPage* newPage = pages[index];
    TabPage* curPage = pages[currentPageIndex];

    // 预备动画
    QGraphicsOpacityEffect* newPageOpac = new QGraphicsOpacityEffect;
    QGraphicsOpacityEffect* curPageOpac = new QGraphicsOpacityEffect;
    newPageOpac->setOpacity(0);
    curPageOpac->setOpacity(1);
    newPage->setGraphicsEffect(newPageOpac);
    curPage->setGraphicsEffect(curPageOpac);
    newPage->show();
    newPage->raise();
    indicator->raise();
    QParallelAnimationGroup* switchPages = new QParallelAnimationGroup(pageContainer);
    QSequentialAnimationGroup* FadeIn = new QSequentialAnimationGroup(pageContainer);
    QPropertyAnimation* newPageFadeIn = new QPropertyAnimation(newPageOpac, "opacity", newPage);
    QPropertyAnimation* newPageMove = new QPropertyAnimation(newPage, "pos");
    QPropertyAnimation* curPageFadeOut = new QPropertyAnimation(curPageOpac, "opacity", curPage);
    QPropertyAnimation* curPageMove = new QPropertyAnimation(curPage, "pos");
    QPropertyAnimation* indicatorScale = new QPropertyAnimation(indicator, "geometry");
    newPageFadeIn->setDuration(600);
    newPageFadeIn->setStartValue(0);
    newPageFadeIn->setEndValue(1);
    newPageFadeIn->setEasingCurve(QEasingCurve::Linear);
    FadeIn->addPause(300);
    FadeIn->addAnimation(newPageFadeIn);
    newPageMove->setDuration(1200);
    newPageMove->setStartValue(QPoint(50, newPage->y()));
    newPageMove->setEndValue(QPoint(0, newPage->y()));
    newPageMove->setEasingCurve(QEasingCurve::InOutQuad);
    curPageFadeOut->setDuration(500);
    curPageFadeOut->setStartValue(1);
    curPageFadeOut->setEndValue(0);
    curPageFadeOut->setEasingCurve(QEasingCurve::Linear);
    curPageMove->setDuration(800);
    curPageMove->setStartValue(QPoint(0, curPage->y()));
    curPageMove->setEndValue(QPoint(-30, curPage->y()));
    curPageMove->setEasingCurve(QEasingCurve::InOutQuad);
    indicatorScale->setDuration(800);
    indicatorScale->setStartValue(QRect(indicator->x(), indicator->y(), indicator->width(), indicator->height()));
    indicatorScale->setEndValue(QRect(tabButtons[index]->x() + 15, indicator->y(), tabButtons[index]->size().width() - 30, indicator->height()));
    indicatorScale->setEasingCurve(QEasingCurve::InOutQuad);

    switchPages->addAnimation(FadeIn);
    switchPages->addAnimation(newPageMove);
    switchPages->addAnimation(curPageFadeOut);
    switchPages->addAnimation(curPageMove);
    switchPages->addAnimation(indicatorScale);

    // 动画开始
    switchPages->start();
    connect(switchPages, &QPropertyAnimation::finished, this, [=]{newPageOpac->deleteLater();});
    tabButtons[currentPageIndex]->SetFocus(false);
    currentPageIndex = index;
    tabButtons[index]->SetFocus(true);
    update();
}
