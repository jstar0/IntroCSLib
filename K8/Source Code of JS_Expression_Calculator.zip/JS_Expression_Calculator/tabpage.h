#ifndef TABPAGE_H
#define TABPAGE_H

#include <QWidget>

class TabPage : public QWidget
{
    Q_OBJECT
public:
    explicit TabPage(QWidget *parent = nullptr);

signals:

};

#endif // TABPAGE_H
